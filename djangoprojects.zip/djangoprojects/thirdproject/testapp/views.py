from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def good_morning_view(request):
    return HttpResponse('<h1> Hello, Good morning! </h1>')

def good_afternoon_view(request):
    return HttpResponse('<h1> Hello, Good afternoon! </h1>')

def good_evening_view(request):
    return HttpResponse('<h1> Hello, Good evening! </h1>')        