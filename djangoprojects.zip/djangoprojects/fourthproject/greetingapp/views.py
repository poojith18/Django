from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def greetings_view(response):
    return HttpResponse('<h1> Good morning.. Have a nice day </h1>')