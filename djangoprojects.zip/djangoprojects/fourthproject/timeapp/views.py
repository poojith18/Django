from django.http import HttpResponse
from django.shortcuts import render

import datetime

# Create your views here.
def time_info_view(request):
    time=datetime.datetime.now()
    s='<h1> Good morning.. current date and time is :' + str(time) + ' </h1>'
    return HttpResponse(s)